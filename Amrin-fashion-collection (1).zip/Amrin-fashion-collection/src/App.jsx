
import React from 'react';

export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Welcome to Amrin Fashion Collection</h1>
      <p>Your fashion destination for Men, Women & Kids.</p>
    </div>
  );
}
